# Hangman

A simple hangman game built in JavaScript. This was built during the first month of class and was not originally tracked with Git. The goal of this project to learn more about
object-oriented programming and become more comfortable using jQuery to build the front end.

To try it out, open `index.html` in your browser of choice. There are three categories pre-built.
If you'd like add more to these (or more categories yourself) just add to the `wordLists` object.

Thanks and enjoy!